package com.example.util

import com.example.model.GuestAccount
import org.json.JSONArray
import org.json.JSONObject

object JsonAccountParser {

    /**
     * Parses JSON string or fallback text into a list of GuestAccounts.
     * Supports both Simple and Full formats, as well as nested structures.
     */
    fun parse(rawText: String): List<GuestAccount> {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return emptyList()

        val results = mutableListOf<GuestAccount>()

        try {
            if (trimmed.startsWith("[")) {
                val jsonArray = JSONArray(trimmed)
                for (i in 0 until jsonArray.length()) {
                    val item = jsonArray.opt(i)
                    if (item is JSONObject) {
                        parseSingleJsonObject(item)?.let { results.add(it) }
                    }
                }
            } else if (trimmed.startsWith("{")) {
                val rootObject = JSONObject(trimmed)

                // Check if it has a guest_account_info object (single cache format)
                if (rootObject.has("guest_account_info")) {
                    val info = rootObject.getJSONObject("guest_account_info")
                    parseSingleJsonObject(info)?.let { results.add(it) }
                } else if (rootObject.has("accounts") || rootObject.has("data") || rootObject.has("list")) {
                    val arrayKey = when {
                        rootObject.has("accounts") -> "accounts"
                        rootObject.has("data") -> "data"
                        else -> "list"
                    }
                    val arr = rootObject.optJSONArray(arrayKey)
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val item = arr.opt(i)
                            if (item is JSONObject) {
                                parseSingleJsonObject(item)?.let { results.add(it) }
                            }
                        }
                    }
                } else {
                    // Try parsing root object as single account
                    parseSingleJsonObject(rootObject)?.let { results.add(it) }
                }
            }
            if (results.isEmpty()) {
                val regexResults = parseWithRegex(trimmed)
                if (regexResults.isNotEmpty()) {
                    return regexResults
                }
            }
        } catch (e: Exception) {
            val regexResults = parseWithRegex(trimmed)
            if (regexResults.isNotEmpty()) {
                return regexResults
            }
            // Fallback: line-by-line parsing (e.g. JSON lines or uid:password lines)
            val lineResults = parseLineByLine(trimmed)
            if (lineResults.isNotEmpty()) {
                return lineResults
            }
        }

        if (results.isEmpty()) {
            val regexResults = parseWithRegex(trimmed)
            if (regexResults.isNotEmpty()) {
                return regexResults
            }
            return parseLineByLine(trimmed)
        }

        return results
    }

    private fun parseWithRegex(text: String): List<GuestAccount> {
        val list = mutableListOf<GuestAccount>()
        // Match JSON-like blocks { ... }
        val objectRegex = Regex("""\{([^{}]+)\}""")
        val matches = objectRegex.findAll(text)

        for (match in matches) {
            val block = match.groupValues[1]
            val uidMatch = Regex("""["']?(?:uid|user_id|userid|guest_uid|com\.garena\.msdk\.guest_uid)["']?\s*:\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(block)
            val passMatch = Regex("""["']?(?:password|pass|pwd|guest_password|com\.garena\.msdk\.guest_password)["']?\s*:\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(block)
            val openIdMatch = Regex("""["']?(?:open_id|openid)["']?\s*:\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(block)
            val jwtMatch = Regex("""["']?(?:jwt|token|access_token)["']?\s*:\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(block)
            val regionMatch = Regex("""["']?(?:region|server)["']?\s*:\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(block)

            val uid = uidMatch?.groupValues?.get(1)?.trim()
            val pass = passMatch?.groupValues?.get(1)?.trim()

            if (!uid.isNullOrEmpty() && !pass.isNullOrEmpty()) {
                list.add(
                    GuestAccount(
                        uid = uid,
                        password = pass,
                        openId = openIdMatch?.groupValues?.get(1)?.trim(),
                        jwt = jwtMatch?.groupValues?.get(1)?.trim(),
                        region = regionMatch?.groupValues?.get(1)?.trim()
                    )
                )
            }
        }
        return list
    }

    private fun parseSingleJsonObject(json: JSONObject): GuestAccount? {
        var uid: String? = null
        var password: String? = null
        var openId: String? = null
        var jwt: String? = null
        var region: String? = null
        val extras = mutableMapOf<String, String>()

        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = json.optString(key, "").trim()
            val lowerKey = key.lowercase()

            when {
                lowerKey in listOf("uid", "user_id", "userid", "guest_uid", "com.garena.msdk.guest_uid", "id") -> {
                    if (uid == null) uid = value
                }
                lowerKey in listOf("password", "pass", "pwd", "guest_password", "com.garena.msdk.guest_password") -> {
                    if (password == null) password = value
                }
                lowerKey in listOf("open_id", "openid") -> {
                    openId = value
                }
                lowerKey in listOf("jwt", "token", "access_token") -> {
                    jwt = value
                }
                lowerKey in listOf("region", "server") -> {
                    region = value
                }
                else -> {
                    if (value.isNotEmpty()) {
                        extras[key] = value
                    }
                }
            }
        }

        if (!uid.isNullOrEmpty() && !password.isNullOrEmpty()) {
            return GuestAccount(
                uid = uid,
                password = password,
                openId = openId,
                jwt = jwt,
                region = region,
                extraFields = extras
            )
        }
        return null
    }

    private fun parseLineByLine(text: String): List<GuestAccount> {
        val list = mutableListOf<GuestAccount>()
        val lines = text.lines()
        for (line in lines) {
            val trimmedLine = line.trim()
            if (trimmedLine.isEmpty()) continue

            // Check if line is single JSON object
            if (trimmedLine.startsWith("{") && trimmedLine.endsWith("}")) {
                try {
                    val obj = JSONObject(trimmedLine)
                    parseSingleJsonObject(obj)?.let { list.add(it) }
                    continue
                } catch (_: Exception) {}
            }

            // Check if delimiter separated like uid:pass or uid,pass or uid\tpass
            val delimiter = when {
                trimmedLine.contains(":") -> ":"
                trimmedLine.contains(",") -> ","
                trimmedLine.contains("|") -> "|"
                trimmedLine.contains("\t") -> "\t"
                else -> null
            }

            if (delimiter != null) {
                val parts = trimmedLine.split(delimiter)
                if (parts.size >= 2) {
                    val u = parts[0].trim()
                    val p = parts[1].trim()
                    if (u.isNotEmpty() && p.isNotEmpty()) {
                        list.add(GuestAccount(uid = u, password = p))
                    }
                }
            }
        }
        return list
    }

    /**
     * Preset sample accounts provided in the prompt for instant testing.
     */
    fun getSampleAccounts(): List<GuestAccount> {
        return listOf(
            GuestAccount(
                uid = "6595344903",
                password = "SRKING_0wy3yJ",
                openId = "e98aca3c29c41c39fe436f199399fa5a",
                jwt = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                region = "IND"
            ),
            GuestAccount(
                uid = "6595344906",
                password = "SRKING_KEZkKH",
                openId = "39b1b81f8dbd8350849bac2464750616",
                jwt = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                region = "IND"
            ),
            GuestAccount(
                uid = "6538455090",
                password = "SRKING_zPEdAJ",
                openId = "a1b2c3d4e5f67890123456789abcdef0",
                jwt = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                region = "IND"
            ),
            GuestAccount(
                uid = "6595344910",
                password = "SRKING_9mPqL0",
                openId = "9f8e7d6c5b4a3210fedcba0987654321",
                jwt = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                region = "IND"
            ),
            GuestAccount(
                uid = "6595344922",
                password = "SRKING_vL82kX",
                openId = "11223344556677889900aabbccddeeff",
                jwt = "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                region = "IND"
            )
        )
    }
}
