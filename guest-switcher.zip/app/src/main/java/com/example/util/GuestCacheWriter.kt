package com.example.util

import android.content.Context
import android.net.Uri
import com.example.model.GuestAccount
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class WriteResult {
    data class Success(val uid: String, val timestamp: String, val destination: String) : WriteResult()
    data class Error(val message: String, val suggestion: String? = null) : WriteResult()
}

object GuestCacheWriter {

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    /**
     * Atomically writes the guest account info to the specified path or SAF Uri.
     */
    fun writeCache(
        context: Context,
        account: GuestAccount,
        filePath: String,
        fileUri: Uri? = null
    ): WriteResult {
        val jsonContent = account.toFreeFireCacheJson(pretty = false)
        val timestamp = timeFormat.format(Date())

        // 1. If SAF Uri is available, write to Uri
        if (fileUri != null) {
            return try {
                context.contentResolver.openOutputStream(fileUri, "wt")?.use { stream ->
                    stream.write(jsonContent.toByteArray(Charsets.UTF_8))
                    stream.flush()
                } ?: return WriteResult.Error("Could not open output stream for selected file URI")

                WriteResult.Success(
                    uid = account.uid,
                    timestamp = timestamp,
                    destination = fileUri.lastPathSegment ?: "Selected File"
                )
            } catch (e: Exception) {
                WriteResult.Error(
                    message = "SAF Write failed: ${e.localizedMessage ?: "Unknown error"}",
                    suggestion = "Try picking or re-creating the cache file using the file selector"
                )
            }
        }

        // 2. Direct File Path atomic write
        val trimmedPath = filePath.trim()
        if (trimmedPath.isEmpty()) {
            return WriteResult.Error("Cache file path is empty", "Specify a path like /sdcard/guest100067.txt")
        }

        return try {
            val targetFile = File(trimmedPath)

            // Ensure parent directory exists if possible
            targetFile.parentFile?.mkdirs()

            // Atomic write: write to temp file then rename
            val tempFile = File(targetFile.parentFile ?: context.cacheDir, "${targetFile.name}.tmp_${System.currentTimeMillis()}")
            
            FileOutputStream(tempFile).use { out ->
                out.write(jsonContent.toByteArray(Charsets.UTF_8))
                out.flush()
                out.fd.sync()
            }

            // Atomically replace target file
            val renamed = if (targetFile.exists()) {
                targetFile.delete()
                tempFile.renameTo(targetFile)
            } else {
                tempFile.renameTo(targetFile)
            }

            if (!renamed) {
                // Fallback direct write
                FileOutputStream(targetFile).use { out ->
                    out.write(jsonContent.toByteArray(Charsets.UTF_8))
                    out.flush()
                    out.fd.sync()
                }
                tempFile.delete()
            }

            WriteResult.Success(
                uid = account.uid,
                timestamp = timestamp,
                destination = targetFile.absolutePath
            )
        } catch (e: SecurityException) {
            WriteResult.Error(
                message = "Storage permission restricted by Android OS: ${e.message}",
                suggestion = "Use the 'Select / Create Cache File' button to pick a file via Storage Access Framework"
            )
        } catch (e: Exception) {
            WriteResult.Error(
                message = "Write error: ${e.localizedMessage ?: e.javaClass.simpleName}",
                suggestion = "Check storage permissions or select a custom location via file picker"
            )
        }
    }

    /**
     * Reads and verifies the current cache content from disk or Uri.
     */
    fun readCurrentCache(
        context: Context,
        filePath: String,
        fileUri: Uri? = null
    ): Pair<String?, String?> {
        val content = try {
            if (fileUri != null) {
                context.contentResolver.openInputStream(fileUri)?.use { stream ->
                    stream.bufferedReader(Charsets.UTF_8).readText()
                }
            } else {
                val file = File(filePath.trim())
                if (file.exists() && file.canRead()) {
                    file.readText(Charsets.UTF_8)
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            null
        }

        if (content.isNullOrBlank()) return Pair(null, null)

        return try {
            val root = JSONObject(content.trim())
            val info = root.optJSONObject("guest_account_info")
            if (info != null) {
                val uid = info.optString("com.garena.msdk.guest_uid", null)
                val pass = info.optString("com.garena.msdk.guest_password", null)
                Pair(uid, pass)
            } else {
                Pair(null, null)
            }
        } catch (e: Exception) {
            Pair(null, null)
        }
    }
}
