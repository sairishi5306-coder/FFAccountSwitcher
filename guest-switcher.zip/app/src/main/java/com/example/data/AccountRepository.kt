package com.example.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import com.example.model.GuestAccount
import com.example.util.GuestCacheWriter
import com.example.util.JsonAccountParser
import com.example.util.WriteResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Shared repository holding the active guest accounts and cache state.
 * Shared between MainActivity/ViewModel and FloatingOverlayService so state is always synced.
 */
object AccountRepository {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val _accounts = MutableStateFlow<List<GuestAccount>>(emptyList())
    val accounts: StateFlow<List<GuestAccount>> = _accounts.asStateFlow()

    private val _currentIndex = MutableStateFlow(0)
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _loadedFileName = MutableStateFlow("activated_IND.json (Preset)")
    val loadedFileName: StateFlow<String> = _loadedFileName.asStateFlow()

    private val _cacheFilePath = MutableStateFlow("/sdcard/guest100067.txt")
    val cacheFilePath: StateFlow<String> = _cacheFilePath.asStateFlow()

    private val _cacheFileUri = MutableStateFlow<Uri?>(null)
    val cacheFileUri: StateFlow<Uri?> = _cacheFileUri.asStateFlow()

    private val _cacheFileName = MutableStateFlow<String?>(null)
    val cacheFileName: StateFlow<String?> = _cacheFileName.asStateFlow()

    private val _autoUpdateCache = MutableStateFlow(true)
    val autoUpdateCache: StateFlow<Boolean> = _autoUpdateCache.asStateFlow()

    private val _lastWriteResult = MutableStateFlow<WriteResult?>(null)
    val lastWriteResult: StateFlow<WriteResult?> = _lastWriteResult.asStateFlow()

    private val _onDiskUid = MutableStateFlow<String?>(null)
    val onDiskUid: StateFlow<String?> = _onDiskUid.asStateFlow()

    private val _isWriting = MutableStateFlow(false)
    val isWriting: StateFlow<Boolean> = _isWriting.asStateFlow()

    private val _statusMessage = MutableStateFlow("Ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _isOverlayRunning = MutableStateFlow(false)
    val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

    init {
        // Preset sample accounts
        val samples = JsonAccountParser.getSampleAccounts()
        _accounts.value = samples
        _currentIndex.value = 0
        _statusMessage.value = "Loaded ${samples.size} accounts"
    }

    val currentAccount: GuestAccount?
        get() {
            val list = _accounts.value
            val idx = _currentIndex.value
            return if (list.isNotEmpty() && idx in list.indices) list[idx] else null
        }

    fun setOverlayRunning(running: Boolean) {
        _isOverlayRunning.value = running
    }

    fun setAccounts(list: List<GuestAccount>, sourceName: String, context: Context? = null) {
        _accounts.value = list
        _currentIndex.value = 0
        _loadedFileName.value = sourceName
        _statusMessage.value = "Loaded ${list.size} accounts from $sourceName"

        if (_autoUpdateCache.value && context != null) {
            writeCacheForCurrentAccount(context)
        }
    }

    fun nextAccount(context: Context): Boolean {
        val total = _accounts.value.size
        val curr = _currentIndex.value
        if (curr < total - 1) {
            _currentIndex.value = curr + 1
            if (_autoUpdateCache.value) {
                writeCacheForCurrentAccount(context)
            }
            return true
        }
        return false
    }

    fun previousAccount(context: Context): Boolean {
        val curr = _currentIndex.value
        if (curr > 0) {
            _currentIndex.value = curr - 1
            if (_autoUpdateCache.value) {
                writeCacheForCurrentAccount(context)
            }
            return true
        }
        return false
    }

    fun jumpToIndex(oneBasedIndex: Int, context: Context) {
        val total = _accounts.value.size
        if (total == 0) return
        val clamped = (oneBasedIndex - 1).coerceIn(0, total - 1)
        _currentIndex.value = clamped
        if (_autoUpdateCache.value) {
            writeCacheForCurrentAccount(context)
        }
    }

    fun setCacheFilePath(path: String, context: Context?) {
        _cacheFilePath.value = path
        _cacheFileUri.value = null
        _cacheFileName.value = null
        if (context != null) verifyDiskCache(context)
    }

    fun setCacheFileUri(uri: Uri, displayName: String?, context: Context?) {
        _cacheFileUri.value = uri
        _cacheFileName.value = displayName ?: "guest100067.txt"
        if (_autoUpdateCache.value && context != null) {
            writeCacheForCurrentAccount(context)
        } else if (context != null) {
            verifyDiskCache(context)
        }
    }

    fun setAutoUpdate(enabled: Boolean, context: Context?) {
        _autoUpdateCache.value = enabled
        if (enabled && context != null) {
            writeCacheForCurrentAccount(context)
        }
    }

    fun writeCacheForCurrentAccount(context: Context, onComplete: ((WriteResult) -> Unit)? = null) {
        val account = currentAccount ?: return
        _isWriting.value = true

        scope.launch(Dispatchers.IO) {
            val result = GuestCacheWriter.writeCache(
                context = context,
                account = account,
                filePath = _cacheFilePath.value,
                fileUri = _cacheFileUri.value
            )

            val onDisk = GuestCacheWriter.readCurrentCache(
                context = context,
                filePath = _cacheFilePath.value,
                fileUri = _cacheFileUri.value
            ).first

            withContext(Dispatchers.Main) {
                _isWriting.value = false
                _lastWriteResult.value = result
                _onDiskUid.value = onDisk
                val status = when (result) {
                    is WriteResult.Success -> "✅ Cache updated: ${result.uid} (${result.timestamp})"
                    is WriteResult.Error -> "⚠️ Cache write issue: ${result.message}"
                }
                _statusMessage.value = status
                onComplete?.invoke(result)
            }
        }
    }

    fun verifyDiskCache(context: Context) {
        scope.launch(Dispatchers.IO) {
            val onDisk = GuestCacheWriter.readCurrentCache(
                context = context,
                filePath = _cacheFilePath.value,
                fileUri = _cacheFileUri.value
            ).first

            withContext(Dispatchers.Main) {
                _onDiskUid.value = onDisk
            }
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
    }
}
