package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Balanced Dark Theme Colors
val DarkBackground = Color(0xFF1A1A2E)
val CardBackground = Color(0xFF16213E)
val CardBackgroundElevated = Color(0xFF1F2E52)
val DeepBlueSecondary = Color(0xFF0F3460)

val PrimaryRedPink = Color(0xFFE94560)
val PrimaryRedDark = Color(0xFFC23152)
val PrimaryRedLight = Color(0xFFFF6584)

val AccentGold = Color(0xFFFFD700)
val AccentGoldLight = Color(0xFFFFE57F)
val AccentCyan = Color(0xFF4ECCA3)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF94A3B8)
val TextDark = Color(0xFF0F172A)

val SuccessGreen = Color(0xFF10B981)
val WarningOrange = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val BorderSubtle = Color(0xFF283A64)

