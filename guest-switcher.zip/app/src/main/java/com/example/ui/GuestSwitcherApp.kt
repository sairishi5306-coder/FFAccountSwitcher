package com.example.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.ui.components.AccountCard
import com.example.ui.components.AllAccountsDialog
import com.example.ui.components.CacheConfigCard
import com.example.ui.components.HeaderBar
import com.example.ui.components.HelpGuideDialog
import com.example.ui.components.NavigationControls
import com.example.ui.components.OverlayControlCard
import com.example.ui.components.PasteJsonDialog
import com.example.ui.components.SourceFileCard
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.CardBackgroundElevated
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DeepBlueSecondary
import com.example.ui.theme.PrimaryRedPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.GuestSwitcherViewModel

@Composable
fun GuestSwitcherApp(
    viewModel: GuestSwitcherViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val uiState by viewModel.uiState.collectAsState()

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshOverlayPermission()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // 1. JSON File Picker Launcher
    val jsonFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment ?: "accounts.json"
            viewModel.loadFromUri(uri, fileName)
        }
    }

    // 2. Cache File Creator / Picker (SAF)
    val cacheFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (_: Exception) {}
            viewModel.setCacheFileUri(uri, "guest100067.txt (SAF)")
            Toast.makeText(context, "Target cache file linked", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        containerColor = DarkBackground,
        bottomBar = {
            // Bottom Action Status Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_bar"),
                color = DeepBlueSecondary,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = uiState.statusMessage,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextWhite,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Top App Bar / Header
            HeaderBar(
                onOpenHelp = { viewModel.setShowHelpDialog(true) }
            )

            // Section 1: Source JSON File Selection
            SourceFileCard(
                loadedFileName = uiState.loadedFileName,
                totalAccounts = uiState.totalAccounts,
                onSelectFile = { jsonFilePickerLauncher.launch("*/*") },
                onPasteJson = { viewModel.setShowPasteJsonDialog(true) },
                onLoadSample = { viewModel.loadSampleData() },
                onViewAllList = { viewModel.setShowAllAccountsSheet(true) }
            )

            // Section 2: Guest Cache Config & Auto-Update
            CacheConfigCard(
                cachePath = uiState.cacheFilePath,
                cacheFileName = uiState.cacheFileName,
                autoUpdate = uiState.autoUpdateCache,
                onDiskUid = uiState.onDiskUid,
                currentUid = uiState.currentAccount?.uid,
                lastWriteResult = uiState.lastWriteResult,
                isWriting = uiState.isWriting,
                onPathChange = { viewModel.setCacheFilePath(it) },
                onPickCacheFile = { cacheFilePickerLauncher.launch("guest100067.txt") },
                onCreateCacheFile = { cacheFilePickerLauncher.launch("guest100067.txt") },
                onAutoUpdateToggle = { viewModel.toggleAutoUpdate(it) },
                onForceWrite = { viewModel.writeCacheForCurrentAccount() }
            )

            // Section 3: Current Account Display Card
            AccountCard(
                account = uiState.currentAccount,
                currentIndex = uiState.currentIndex,
                totalAccounts = uiState.totalAccounts,
                isPasswordVisible = uiState.isPasswordVisible,
                onTogglePasswordVisibility = { viewModel.togglePasswordVisibility() },
                onCopyUid = { viewModel.copyToClipboard("UID", it) },
                onCopyPassword = { viewModel.copyToClipboard("Password", it) },
                onCopyJson = { viewModel.copyToClipboard("Cache JSON", it) }
            )

            // Section 4: In-Game Floating Overlay Card
            OverlayControlCard(
                isOverlayRunning = uiState.isOverlayRunning,
                hasPermission = uiState.hasOverlayPermission,
                onStartOverlay = { viewModel.startOverlayService() },
                onStopOverlay = { viewModel.stopOverlayService() },
                onRefreshPermission = { viewModel.refreshOverlayPermission() }
            )

            // Section 5: Navigation Controls
            NavigationControls(
                currentIndex = uiState.currentIndex,
                totalAccounts = uiState.totalAccounts,
                hasPrevious = uiState.hasPrevious,
                hasNext = uiState.hasNext,
                onPrevious = { viewModel.previousAccount() },
                onNext = { viewModel.nextAccount() },
                onJumpToIndex = { viewModel.jumpToIndex(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Modal Dialogs
    if (uiState.showAllAccountsSheet) {
        AllAccountsDialog(
            accounts = uiState.accounts,
            currentIndex = uiState.currentIndex,
            onSelectAccount = { viewModel.selectAccountAtIndex(it) },
            onDismiss = { viewModel.setShowAllAccountsSheet(false) }
        )
    }

    if (uiState.showPasteJsonDialog) {
        PasteJsonDialog(
            onLoadJson = { text, name -> viewModel.loadFromJsonText(text, name) },
            onDismiss = { viewModel.setShowPasteJsonDialog(false) }
        )
    }

    if (uiState.showHelpDialog) {
        HelpGuideDialog(
            onDismiss = { viewModel.setShowHelpDialog(false) }
        )
    }
}
