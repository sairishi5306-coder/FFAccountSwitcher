package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBackgroundElevated
import com.example.ui.theme.DeepBlueSecondary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryRedPink
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.util.WriteResult

@Composable
fun CacheConfigCard(
    cachePath: String,
    cacheFileName: String?,
    autoUpdate: Boolean,
    onDiskUid: String?,
    currentUid: String?,
    lastWriteResult: WriteResult?,
    isWriting: Boolean,
    onPathChange: (String) -> Unit,
    onPickCacheFile: () -> Unit,
    onCreateCacheFile: () -> Unit,
    onAutoUpdateToggle: (Boolean) -> Unit,
    onForceWrite: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isEditingPath by remember { mutableStateOf(false) }
    var tempPath by remember(cachePath) { mutableStateOf(cachePath) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("cache_config_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FolderShared,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Guest Cache Target (Free Fire)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            fontSize = 15.sp
                        )
                    )
                }

                // Force Sync button
                OutlinedButton(
                    onClick = onForceWrite,
                    enabled = !isWriting && currentUid != null,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    border = BorderStroke(1.dp, PrimaryRedPink.copy(alpha = 0.6f)),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = CardBackgroundElevated),
                    modifier = Modifier
                        .height(32.dp)
                        .testTag("force_sync_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Sync Cache Now",
                        tint = PrimaryRedPink,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isWriting) "Syncing..." else "Sync Now",
                        fontSize = 11.sp,
                        color = PrimaryRedPink,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // File path view / edit
            if (!isEditingPath) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CardBackgroundElevated)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Target Path / URI",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        )
                        Text(
                            text = cacheFileName ?: cachePath,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AccentCyan,
                                fontWeight = FontWeight.SemiBold
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { isEditingPath = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Path",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = onPickCacheFile,
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("pick_cache_file_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CreateNewFolder,
                                contentDescription = "Pick / Create File",
                                tint = AccentGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = tempPath,
                        onValueChange = { tempPath = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("cache_path_input"),
                        label = { Text("Path (e.g. /sdcard/guest100067.txt)", fontSize = 11.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryRedPink,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedButton(
                        onClick = {
                            onPathChange(tempPath)
                            isEditingPath = false
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(50.dp)
                    ) {
                        Text("Save", color = AccentGold, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Auto-update switch & disk status row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(DeepBlueSecondary.copy(alpha = 0.5f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Auto-Update Cache on Switch",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            fontSize = 13.sp
                        )
                    )
                    Text(
                        text = "Auto writes guest100067.txt on next/prev",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    )
                }

                Switch(
                    checked = autoUpdate,
                    onCheckedChange = onAutoUpdateToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = TextWhite,
                        checkedTrackColor = PrimaryRedPink,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CardBackgroundElevated
                    ),
                    modifier = Modifier.testTag("auto_update_switch")
                )
            }

            // Real-time On-Disk Verification Status
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (onDiskUid != null && onDiskUid == currentUid) {
                            SuccessGreen.copy(alpha = 0.15f)
                        } else if (onDiskUid != null) {
                            DeepBlueSecondary
                        } else {
                            CardBackgroundElevated
                        }
                    )
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (onDiskUid != null && onDiskUid == currentUid) {
                        Icons.Default.CheckCircle
                    } else if (lastWriteResult is WriteResult.Error) {
                        Icons.Default.Warning
                    } else {
                        Icons.Default.CheckCircle
                    },
                    contentDescription = null,
                    tint = if (onDiskUid != null && onDiskUid == currentUid) SuccessGreen else AccentGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when {
                        onDiskUid != null && onDiskUid == currentUid -> "✅ Cache Synced on Disk: UID $onDiskUid"
                        onDiskUid != null -> "⚠️ Cache has UID: $onDiskUid (Current: ${currentUid ?: "None"})"
                        lastWriteResult is WriteResult.Success -> "✅ Cache updated: ${lastWriteResult.uid} (${lastWriteResult.timestamp})"
                        lastWriteResult is WriteResult.Error -> "⚠️ ${lastWriteResult.message}"
                        else -> "Cache ready: /sdcard/guest100067.txt"
                    },
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (onDiskUid != null && onDiskUid == currentUid) SuccessGreen else TextWhite,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
