package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentGold
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardBackground
import com.example.ui.theme.CardBackgroundElevated
import com.example.ui.theme.DeepBlueSecondary
import com.example.ui.theme.PrimaryRedDark
import com.example.ui.theme.PrimaryRedPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

@Composable
fun NavigationControls(
    currentIndex: Int,
    totalAccounts: Int,
    hasPrevious: Boolean,
    hasNext: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onJumpToIndex: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var jumpText by remember(currentIndex) { mutableStateOf((currentIndex + 1).toString()) }
    val keyboardController = LocalSoftwareKeyboardController.current

    val executeJump = {
        val target = jumpText.toIntOrNull()
        if (target != null && target in 1..totalAccounts) {
            onJumpToIndex(target)
            keyboardController?.hide()
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Prev / Next Navigation Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Previous Button
            Button(
                onClick = onPrevious,
                enabled = hasPrevious,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("prev_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    disabledContainerColor = CardBackgroundElevated.copy(alpha = 0.5f)
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .background(
                            if (hasPrevious) {
                                Brush.horizontalGradient(listOf(DeepBlueSecondary, CardBackgroundElevated))
                            } else {
                                Brush.horizontalGradient(listOf(CardBackground, CardBackground))
                            },
                            shape = RoundedCornerShape(12.dp)
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Account",
                        tint = if (hasPrevious) TextWhite else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Previous",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (hasPrevious) TextWhite else TextMuted,
                            fontSize = 15.sp
                        )
                    )
                }
            }

            // Next Button (Primary Gradient)
            Button(
                onClick = onNext,
                enabled = hasNext,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("next_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    disabledContainerColor = CardBackgroundElevated.copy(alpha = 0.5f)
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .background(
                            if (hasNext) {
                                Brush.horizontalGradient(listOf(PrimaryRedPink, PrimaryRedDark))
                            } else {
                                Brush.horizontalGradient(listOf(CardBackground, CardBackground))
                            },
                            shape = RoundedCornerShape(12.dp)
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Next Account",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (hasNext) TextWhite else TextMuted,
                            fontSize = 15.sp
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Next Account",
                        tint = if (hasNext) TextWhite else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Jump To input and Scrub slider row
        if (totalAccounts > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CardBackground, shape = RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Pin,
                        contentDescription = null,
                        tint = AccentGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    OutlinedTextField(
                        value = jumpText,
                        onValueChange = { input ->
                            val filtered = input.filter { it.isDigit() }.take(5)
                            jumpText = filtered
                        },
                        modifier = Modifier
                            .width(80.dp)
                            .height(48.dp)
                            .testTag("jump_to_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(onDone = { executeJump() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryRedPink,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "/ $totalAccounts",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextMuted,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                Button(
                    onClick = executeJump,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryRedDark),
                    modifier = Modifier
                        .height(38.dp)
                        .testTag("jump_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.TravelExplore,
                        contentDescription = null,
                        tint = TextWhite,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Jump",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            fontSize = 12.sp
                        )
                    )
                }
            }

            // Slider for fast scrub if more than 3 accounts
            if (totalAccounts > 2) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = (currentIndex + 1).toFloat(),
                        onValueChange = { value ->
                            onJumpToIndex(value.toInt())
                        },
                        valueRange = 1f..totalAccounts.toFloat(),
                        steps = if (totalAccounts <= 20) totalAccounts - 2 else 0,
                        colors = SliderDefaults.colors(
                            thumbColor = AccentGold,
                            activeTrackColor = PrimaryRedPink,
                            inactiveTrackColor = CardBackgroundElevated
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("accounts_slider")
                    )
                }
            }
        }
    }
}
