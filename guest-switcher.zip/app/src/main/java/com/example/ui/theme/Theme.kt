package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CustomDarkColorScheme = darkColorScheme(
    primary = PrimaryRedPink,
    onPrimary = TextWhite,
    primaryContainer = PrimaryRedDark,
    onPrimaryContainer = TextWhite,
    secondary = DeepBlueSecondary,
    onSecondary = TextWhite,
    secondaryContainer = CardBackgroundElevated,
    onSecondaryContainer = TextWhite,
    tertiary = AccentGold,
    onTertiary = TextDark,
    background = DarkBackground,
    onBackground = TextWhite,
    surface = CardBackground,
    onSurface = TextWhite,
    surfaceVariant = CardBackgroundElevated,
    onSurfaceVariant = TextMuted,
    outline = BorderSubtle,
    error = ErrorRed,
    onError = TextWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CustomDarkColorScheme,
        typography = Typography,
        content = content
    )
}

