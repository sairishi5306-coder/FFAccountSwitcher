package com.example.model

data class GuestAccount(
    val uid: String,
    val password: String,
    val openId: String? = null,
    val jwt: String? = null,
    val region: String? = null,
    val extraFields: Map<String, String> = emptyMap()
) {
    /**
     * Builds the exact Free Fire guest cache file JSON structure.
     */
    fun toFreeFireCacheJson(pretty: Boolean = true): String {
        return if (pretty) {
            "{\n  \"guest_account_info\": {\n    \"com.garena.msdk.guest_password\": \"$password\",\n    \"com.garena.msdk.guest_uid\": \"$uid\"\n  }\n}"
        } else {
            "{\"guest_account_info\":{\"com.garena.msdk.guest_password\":\"$password\",\"com.garena.msdk.guest_uid\":\"$uid\"}}"
        }
    }
}
