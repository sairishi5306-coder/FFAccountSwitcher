package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AccountRepository
import com.example.model.GuestAccount
import com.example.service.FloatingOverlayService
import com.example.util.JsonAccountParser
import com.example.util.WriteResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class GuestSwitcherUiState(
    val accounts: List<GuestAccount> = emptyList(),
    val currentIndex: Int = 0,
    val loadedFileName: String = "activated_IND.json (Preset)",
    val cacheFilePath: String = "/sdcard/guest100067.txt",
    val cacheFileUri: Uri? = null,
    val cacheFileName: String? = null,
    val autoUpdateCache: Boolean = true,
    val isPasswordVisible: Boolean = false,
    val lastWriteResult: WriteResult? = null,
    val onDiskUid: String? = null,
    val isWriting: Boolean = false,
    val jumpToInput: String = "1",
    val searchQuery: String = "",
    val showAllAccountsSheet: Boolean = false,
    val showPasteJsonDialog: Boolean = false,
    val showHelpDialog: Boolean = false,
    val statusMessage: String = "Ready",
    val isOverlayRunning: Boolean = false,
    val hasOverlayPermission: Boolean = false
) {
    val currentAccount: GuestAccount?
        get() = if (accounts.isNotEmpty() && currentIndex in accounts.indices) accounts[currentIndex] else null

    val totalAccounts: Int
        get() = accounts.size

    val hasPrevious: Boolean
        get() = currentIndex > 0

    val hasNext: Boolean
        get() = currentIndex < accounts.size - 1
}

class GuestSwitcherViewModel(application: Application) : AndroidViewModel(application) {

    private val _localUi = MutableStateFlow(
        LocalUiState(
            isPasswordVisible = false,
            searchQuery = "",
            showAllAccountsSheet = false,
            showPasteJsonDialog = false,
            showHelpDialog = false,
            hasOverlayPermission = checkOverlayPermissionInternal()
        )
    )

    private data class LocalUiState(
        val isPasswordVisible: Boolean = false,
        val searchQuery: String = "",
        val showAllAccountsSheet: Boolean = false,
        val showPasteJsonDialog: Boolean = false,
        val showHelpDialog: Boolean = false,
        val hasOverlayPermission: Boolean = false
    )

    val uiState: StateFlow<GuestSwitcherUiState> = combine(
        AccountRepository.accounts,
        AccountRepository.currentIndex,
        AccountRepository.loadedFileName,
        AccountRepository.cacheFilePath,
        AccountRepository.cacheFileUri,
        AccountRepository.cacheFileName,
        AccountRepository.autoUpdateCache,
        AccountRepository.lastWriteResult,
        AccountRepository.onDiskUid,
        AccountRepository.isWriting,
        AccountRepository.statusMessage,
        AccountRepository.isOverlayRunning,
        _localUi
    ) { args: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        val accounts = args[0] as List<GuestAccount>
        val currentIndex = args[1] as Int
        val loadedFileName = args[2] as String
        val cacheFilePath = args[3] as String
        val cacheFileUri = args[4] as Uri?
        val cacheFileName = args[5] as String?
        val autoUpdateCache = args[6] as Boolean
        val lastWriteResult = args[7] as WriteResult?
        val onDiskUid = args[8] as String?
        val isWriting = args[9] as Boolean
        val statusMessage = args[10] as String
        val isOverlayRunning = args[11] as Boolean
        val local = args[12] as LocalUiState

        GuestSwitcherUiState(
            accounts = accounts,
            currentIndex = currentIndex,
            loadedFileName = loadedFileName,
            cacheFilePath = cacheFilePath,
            cacheFileUri = cacheFileUri,
            cacheFileName = cacheFileName,
            autoUpdateCache = autoUpdateCache,
            isPasswordVisible = local.isPasswordVisible,
            lastWriteResult = lastWriteResult,
            onDiskUid = onDiskUid,
            isWriting = isWriting,
            jumpToInput = (currentIndex + 1).toString(),
            searchQuery = local.searchQuery,
            showAllAccountsSheet = local.showAllAccountsSheet,
            showPasteJsonDialog = local.showPasteJsonDialog,
            showHelpDialog = local.showHelpDialog,
            statusMessage = statusMessage,
            isOverlayRunning = isOverlayRunning,
            hasOverlayPermission = local.hasOverlayPermission
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = GuestSwitcherUiState(
            accounts = AccountRepository.accounts.value,
            currentIndex = AccountRepository.currentIndex.value,
            hasOverlayPermission = checkOverlayPermissionInternal()
        )
    )

    init {
        AccountRepository.verifyDiskCache(getApplication())
    }

    private fun checkOverlayPermissionInternal(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(getApplication())
        } else {
            true
        }
    }

    fun refreshOverlayPermission() {
        val granted = checkOverlayPermissionInternal()
        _localUi.update { it.copy(hasOverlayPermission = granted) }
    }

    fun startOverlayService() {
        if (!checkOverlayPermissionInternal()) {
            _localUi.update { it.copy(hasOverlayPermission = false) }
            Toast.makeText(getApplication(), "Please grant 'Display over other apps' permission first", Toast.LENGTH_LONG).show()
            return
        }
        _localUi.update { it.copy(hasOverlayPermission = true) }
        FloatingOverlayService.start(getApplication())
        Toast.makeText(getApplication(), "Floating In-Game Overlay Started 🎮", Toast.LENGTH_SHORT).show()
    }

    fun stopOverlayService() {
        FloatingOverlayService.stop(getApplication())
        AccountRepository.setOverlayRunning(false)
        Toast.makeText(getApplication(), "Floating Overlay Stopped", Toast.LENGTH_SHORT).show()
    }

    fun loadSampleData() {
        val sampleAccounts = JsonAccountParser.getSampleAccounts()
        AccountRepository.setAccounts(sampleAccounts, "activated_IND.json (Preset)", getApplication())
    }

    fun loadFromJsonText(text: String, sourceName: String) {
        viewModelScope.launch(Dispatchers.Default) {
            val parsed = JsonAccountParser.parse(text)
            withContext(Dispatchers.Main) {
                if (parsed.isEmpty()) {
                    Toast.makeText(getApplication(), "No valid UID & password found in JSON", Toast.LENGTH_LONG).show()
                } else {
                    AccountRepository.setAccounts(parsed, sourceName, getApplication())
                    _localUi.update { it.copy(showPasteJsonDialog = false) }
                    Toast.makeText(getApplication(), "Loaded ${parsed.size} accounts", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun loadFromUri(uri: Uri, displayName: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val content = getApplication<Application>().contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader(Charsets.UTF_8).readText()
                } ?: ""

                val fileName = displayName ?: uri.lastPathSegment ?: "accounts.json"
                withContext(Dispatchers.Main) {
                    loadFromJsonText(content, fileName)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Error reading file: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun nextAccount() {
        AccountRepository.nextAccount(getApplication())
    }

    fun previousAccount() {
        AccountRepository.previousAccount(getApplication())
    }

    fun jumpToIndex(oneBasedIndex: Int) {
        AccountRepository.jumpToIndex(oneBasedIndex, getApplication())
    }

    fun selectAccountAtIndex(index: Int) {
        AccountRepository.jumpToIndex(index + 1, getApplication())
        _localUi.update { it.copy(showAllAccountsSheet = false) }
    }

    fun setCacheFilePath(path: String) {
        AccountRepository.setCacheFilePath(path, getApplication())
    }

    fun setCacheFileUri(uri: Uri, displayName: String?) {
        AccountRepository.setCacheFileUri(uri, displayName, getApplication())
    }

    fun toggleAutoUpdate(enabled: Boolean) {
        AccountRepository.setAutoUpdate(enabled, getApplication())
    }

    fun togglePasswordVisibility() {
        _localUi.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun setSearchQuery(query: String) {
        _localUi.update { it.copy(searchQuery = query) }
    }

    fun setShowAllAccountsSheet(show: Boolean) {
        _localUi.update { it.copy(showAllAccountsSheet = show) }
    }

    fun setShowPasteJsonDialog(show: Boolean) {
        _localUi.update { it.copy(showPasteJsonDialog = show) }
    }

    fun setShowHelpDialog(show: Boolean) {
        _localUi.update { it.copy(showHelpDialog = show) }
    }

    fun writeCacheForCurrentAccount() {
        AccountRepository.writeCacheForCurrentAccount(getApplication())
    }

    fun verifyDiskCache() {
        AccountRepository.verifyDiskCache(getApplication())
    }

    fun copyToClipboard(label: String, text: String) {
        AccountRepository.copyToClipboard(getApplication(), label, text)
    }
}
