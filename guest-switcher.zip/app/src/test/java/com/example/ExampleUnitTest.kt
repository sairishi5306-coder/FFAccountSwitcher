package com.example

import com.example.util.JsonAccountParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
    @Test
    fun parseSimpleFormat() {
        val json = """
            [
              {"uid": "1234567890", "password": "pass123"},
              {"uid": "0987654321", "password": "pass456"}
            ]
        """.trimIndent()
        val accounts = JsonAccountParser.parse(json)
        assertEquals(2, accounts.size)
        assertEquals("1234567890", accounts[0].uid)
        assertEquals("pass123", accounts[0].password)
        assertEquals("0987654321", accounts[1].uid)
        assertEquals("pass456", accounts[1].password)
    }

    @Test
    fun parseFullFormatWithExtraFields() {
        val json = """
            [
              {
                "uid": "6595344903",
                "password": "SRKING_0wy3yJ",
                "open_id": "e98aca3c29c41c39fe436f199399fa5a",
                "jwt": "eyJhbGciOiJIUzI1NiIsInN2ciI6IjMiLCJ0eXAiOiJKV1QifQ...",
                "region": "IND"
              }
            ]
        """.trimIndent()
        val accounts = JsonAccountParser.parse(json)
        assertEquals(1, accounts.size)
        assertEquals("6595344903", accounts[0].uid)
        assertEquals("SRKING_0wy3yJ", accounts[0].password)
        assertEquals("IND", accounts[0].region)
        assertNotNull(accounts[0].openId)
    }

    @Test
    fun generateFreeFireCacheJson() {
        val sample = JsonAccountParser.getSampleAccounts().first()
        val json = sample.toFreeFireCacheJson(pretty = false)
        assertTrue(json.contains("guest_account_info"))
        assertTrue(json.contains("com.garena.msdk.guest_uid"))
        assertTrue(json.contains("com.garena.msdk.guest_password"))
        assertTrue(json.contains("6595344903"))
    }
}


